Installiere via:

1. Kopiere die Dateien nach ~/AUREON
2. Mache system_status_check.sh ausführbar:
   chmod +x system_status_check.sh
3. Starte: python3 aureon_ui_final.py